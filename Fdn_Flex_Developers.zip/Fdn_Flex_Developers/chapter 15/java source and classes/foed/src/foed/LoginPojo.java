package foed;

public class LoginPojo {

	public LoginPojo(){
		//emty		
	}
	
	public boolean login(String userName,String passWord){
		if((userName.equals("koen")) && (passWord.equals("friendsofed"))){
			return true;
		}else{
			return false;
		}
	}	
}
