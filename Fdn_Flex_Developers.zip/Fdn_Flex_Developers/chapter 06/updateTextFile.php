<?php
$strFilePath = 'E:\aip\clients\Apress-FriendsOfEd\Data Driven Flex Applications\chapter 06\Flex project\assets\news.txt';
$strTitle = $_POST['title'];
$strContent = $_POST['content'];

if ($strTitle != "") { 
	 $output = 'title=' . $strTitle . '&content=' . $strContent;
	 $fileOpener = fopen($strFilePath, 'w');
	 fwrite($fileOpener, $output);
	 fclose($fileOpener);
}
?>
