Chapter 15 : Solutions
---------------------------

//DIR : config_files_solutions
	These config files must be place in the WEB-INF/flex directory of your context root. For tomcat is that in the at ..\Apache Software Foundation\Tomcat 6.0\webapps\flex\WEB-INF\flex and for JRUN is that ..\lcds\jrun4\servers\default\flex\WEB-INF\flex

//DIR : database
	The database directory must be placed in a easy to navigate to location: for Example in the root of your PC like C:/database

//DIR : exercises  
	This directory contains all the solutions for the exercises. In order to run the exercises you must place these folders in the WEB-INF/flex directory of your context root.

//DIR : book application
	The foed directory must be placed in the ...lcds\jrun4\servers\default\flex to get the solution working

Chapter 16: Case study solution
-------------------------------
- To get the case study running you must copy the config_files_solutions and database from chapter 15. 
- The foed directory must be placed in the ...lcds\jrun4\servers\default\flex to get the solution working.

If you want to build the case-study yourself, take the book application from chapter 15 as start file.

