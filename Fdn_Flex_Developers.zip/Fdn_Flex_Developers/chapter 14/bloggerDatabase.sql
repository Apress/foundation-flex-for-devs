CREATE TABLE posts (
  postID int(11) NOT NULL auto_increment,
  postDate date NOT NULL default '0000-00-00',
  postTitle varchar(100) NOT NULL default '',
  postContent text NOT NULL,
  PRIMARY KEY  (postID)
) TYPE=MyISAM AUTO_INCREMENT=16 ;

INSERT INTO posts VALUES (13, '2007-08-01', 'A current post', 'This post is all about the Blogger application. The application interface is built in Flex. The data comes from a mySQL database and PHP pages generate the relevant content using an XML structure consistent with the RSS 2.0 specification.');
INSERT INTO posts VALUES (14, '2007-07-15', 'An archived post.', 'This content is contained within an archived post. The blogger application allows the user to edit or delete an archived entry.');
